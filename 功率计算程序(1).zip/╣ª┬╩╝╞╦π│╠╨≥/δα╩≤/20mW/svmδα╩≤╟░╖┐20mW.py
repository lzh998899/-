import numpy as np
from scipy.integrate import odeint, quad

# 参数
I0 = 31.44654  # 入射辐照度 mW/cm²
mu_a = 0.0078  # 吸收系数 mm⁻¹
mu_s = 0.0060  # 散射系数 mm⁻¹
d = 1.60023    # 厚度 mm
g = 0.9        # 各向异性系数

# Henyey-Greenstein相位函数积分
def p(cos_theta):
    return (1 - g**2) / (1 + g**2 - 2 * g * cos_theta)**(3/2)

def scattering_integral():
    integral, _ = quad(lambda cos_theta: p(cos_theta), -1, 1)
    return integral

# RTE 辐射传输方程
def intensity_derivative(I, s):
    integral_term = (mu_s / (4 * np.pi)) * scattering_integral() * I
    return - (mu_a + mu_s) * I + integral_term

# 解微分方程
def RTE_solver(I0, mu_a, mu_s, d):
    s_values = [0, d]
    I_final = odeint(intensity_derivative, I0, s_values)[-1]
    return I_final

# 计算结果
attenuated_intensity = RTE_solver(I0, mu_a, mu_s, d)
print("最终衰减后的辐照度（光强）是:", attenuated_intensity, "mW/cm²")
