import numpy as np
from scipy.integrate import odeint, quad

# 给定参数
I0 = 30.5465  # mW/cm², 入射辐照度
mu_a = 0.048  # mm^-1, 吸收系数
mu_s = 0.0003  # mm^-1, 散射系数
d = 3.17659   # mm, 玻璃体厚度
g = 0.9       # Henyey-Greenstein相位函数的各向异性因子

# Henyey-Greenstein相位函数
def p(cos_theta):
    return (1 - g**2) / (1 + g**2 - 2 * g * cos_theta)**(3/2)

# 计算散射角度积分
def scattering_integral():
    integral, _ = quad(lambda cos_theta: p(cos_theta), -1, 1)
    return integral

# RTE 辐射传输方程的计算
def intensity_derivative(I, s):
    scattering_integral_value = scattering_integral()
    integral_term = (mu_s / (4 * np.pi)) * scattering_integral_value * I
    return - (mu_a + mu_s) * I + integral_term

# 数值解微分方程
def RTE_solver(I0, mu_a, mu_s, d):
    s_values = [0, d]
    I_final = odeint(intensity_derivative, I0, s_values)[-1]
    return I_final

# 计算最终衰减辐照度
attenuated_intensity = RTE_solver(I0, mu_a, mu_s, d)

# 输出结果
print(f"最终衰减后的辐照度为: {attenuated_intensity[0]:.4f} mW/cm²")
