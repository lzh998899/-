import numpy as np
from scipy.integrate import quad

# 给定参数
I0 = 15.3005  # mW/cm^2, 入射辐照度
mu_a = 0.048  # mm^-1, 吸收系数
mu_s = 0.0003  # mm^-1, 散射系数
d = 3.17659  # mm, 玻璃体厚度
g = 0.9  # Henyey-Greenstein相位函数的各向异性因子

# Henyey-Greenstein相位函数
def p(cos_theta):
    return (1 - g**2) / (1 + g**2 - 2 * g * cos_theta)**(3/2)

# RTE辐射传输方程的计算
def RTE_solver(I0, mu_a, mu_s, d, g):
    # 对散射角度积分，计算散射对强度的贡献
    scattering_integral, _ = quad(lambda cos_theta: p(cos_theta), -1, 1)
    
    # 考虑吸收和散射后的最终强度计算
    I_d = I0 * np.exp(-(mu_a + mu_s) * d) + (mu_s / (4 * np.pi)) * scattering_integral * I0 * d
    return I_d

# 计算结果
attenuated_intensity = RTE_solver(I0, mu_a, mu_s, d, g)

# 输出结果
print(f"经过玻璃体后的衰减辐照度为: {attenuated_intensity:.4f} mW/cm²")
